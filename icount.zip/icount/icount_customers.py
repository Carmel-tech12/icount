import requests
import xml.dom.minidom
import json
import csv
import xml.etree.ElementTree as ET
from xml.etree import ElementTree

url = "https://api.icount.co.il/api/v3.php/auth/login"
customers_url = "https://gueli-dor.dira2.co.il/customers/importcsv"
user ='saed'
password = 'Football13'

'''login to icount api'''

data = {}
data["user"] = "ariege88"
data["cid"] = "phdpltd"
data["pass"] = "7881Aa"
jsonData = requests.post(url, data)
result = jsonData.json()

'''get customers'''

api_costumers = "https://api.icount.co.il/api/v1.php"
data = {}
data["user"] = "ariege88"
data["compID"]="phdpltd"
data["pass"] = "7881Aa"
# data["sid"]=result['sid']
data["sid"]=result['sid']
data["action"] = "get_clients"
data["method"] = "json"
# data["limit"] = "10"
json = requests.post(api_costumers,data)


# print (json.json())
info = json.json()
clientList = info['clients']
# print (clientList)

result = []
for row in clientList:
    my_dict = {}
    my_dict['AccountKey'] = row.get('id')
    my_dict['FullName'] = row.get('company_name')
    my_dict['Balance'] = row.get('balance')
    my_dict['SortGroup'] = '0'
    my_dict['Address'] = '0'
    my_dict['City'] = '0'
    my_dict['Zip'] = '0'
    my_dict['Country'] = '0'
    my_dict['Phone'] = '0'
    my_dict['Fax'] = '0'
    my_dict['MaxCredit'] = '0'
    my_dict['TFtalDiscount'] = '0'
    my_dict['BankCode'] = '0'
    my_dict['BranchCode'] = '0'
    my_dict['BankAccount'] = '0'
    my_dict['TaxFileNum'] = '0'
    my_dict['RowCnt'] = '0'
    my_dict['Obligo'] = '0'
    my_dict['Agent'] = '0'

    # print (my_dict)
    result.append(my_dict)
    import sys

    # reload(sys)
    # sys.setdefaultencoding('utf8')
    with open('C:\Projects\icount\customers.csv', 'w', encoding='utf8')as csvfile:
         writer = csv.DictWriter(csvfile, fieldnames=result[0].keys())

         writer.writeheader()

         for row in result:
            '''
            for key,value in row.iteritems():
                try:
                    row[key] = value.encode("utf-8")
                except:
                    print value
                row[key] = value.encode("cp1255")
            '''
            writer.writerow(row)




''' send customers csv'''

data = {}
data["email"] = user
data["password"] = password
with open('C:\Projects\icount\customers.csv', 'rb') as f:
    files = {'file': f}
    sendCsv = requests.post(customers_url, files=files, data=data)
# print ('done_customers')