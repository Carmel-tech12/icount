import requests
import xml.dom.minidom
import json
import csv
import xml.etree.ElementTree as ET
from xml.etree import ElementTree

url = "https://api.icount.co.il/api/v3.php/auth/login"
products_url = "https://gueli-dor.dira2.co.il/products/importcsv"
user ='saed'
password = 'Football13'

'''login to icount api'''

data = {}
data["user"] = "ariege88"
data["cid"] = "phdpltd"
data["pass"] = "7881Aa"
jsonData = requests.post(url, data)
result = jsonData.json()


'''get products'''

url_inventory = "https://api.icount.co.il/api/v3.php/inventory/get_items"
items_json = requests.post(url_inventory,{"sid":result['sid']})

info = items_json.json()
items =info['items']
# print (items['296'])
val =(list(items.keys())[0])
#print (list(items.keys())[0])
#print (items[val].keys())

'''save products to csv'''

result = []
for row in items:
    # print (items[row])
    my_dict = {}
    my_dict['ItemName'] = items[row]['description']
    my_dict['itemkey'] = items[row]['inventory_item_id']
    my_dict['item_group'] = '0'
    my_dict['units_of_measures_available_for_product'] = '0'
    my_dict['price'] = items[row]['cost_amount']
    my_dict['minimum_price'] = '0'
    my_dict['discount_percentage'] = '0'
    my_dict['list_price_1'] = '0'
    my_dict['list_price_2'] = '0'
    my_dict['list_price_3'] = '0'
    my_dict['list_price_4'] = '0'
    # print (my_dict)
    result.append(my_dict)

    import sys
    #
    # reload(sys)
    # sys.setdefaultencoding('utf8')

    with open('C:\Projects\icount\Products.csv', 'w',encoding='utf8') as csvfile:
         writer = csv.DictWriter(csvfile, fieldnames=result[0].keys())
         writer.writeheader()
         for row in result:
            writer.writerow(row)

'''send products csv'''

data = {}
data["email"] = user
data["password"] = password
with open('C:\Projects\icount\Products.csv', 'rb') as f:
    files = {'file': f}
    # sendCsv = requests.post(products_url,dfiles = files)
    sendCsv = requests.post(products_url, files=files, data=data)
# print ('done_products')




