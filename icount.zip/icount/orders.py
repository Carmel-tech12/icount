import requests
import xml.dom.minidom
import json
import csv
import xml.etree.ElementTree as ET
from xml.etree import ElementTree
# import wget
import shutil


# url = "https://api.icount.co.il/api/v3.php/auth/login"
# # customers_url = "https://gueli-dor.dira2.co.il/customers/importcsv"
# # user ='saed'
# # password = 'Football13'
# #
# # '''login to icount api'''
# #
# d = {}
# d["user"] = "ariege88"
# d["cid"] = "phdpltd"
# d["pass"] = "7881Aa"
# jsonData = requests.post(url, d)
# result = jsonData.json()

# import sys
#
# reload(sys)
# sys.setdefaultencoding('utf8')

# import sys
#
# reload(sys)
# sys.setdefaultencoding('utf8')

url = "https://gueli-dor.dira2.co.il/systems/imovein"
user ='saed'
password = 'Football13'
data = {}
data["email"] = user
data["password"] = password
r = requests.post(url, data=data)

with open('C:\Projects\icount\imovein.doc', 'wb') as file:
     file.write(r.content)


'''parse prm'''

list = []

with open("C:\Projects\icount\imovein.doc", 'r') as orders:
    for order in orders:
        d = {}
        with open ("C:\Projects\icount\Imovein.prm",encoding='utf8', errors='ignore') as f:
            next(f)
            for line in f:
                # print(line)
                places =line[0:10]
                # decString = (places.decode("utf-8"))
                arrayLine = places.split(" ")
                # # print (arrayLine)
                start = int(arrayLine[0])
                end = (arrayLine[arrayLine.__len__()-2])
                if(not end):
                     # print("emptyyyy")
                     continue
                else:
                     end = int(end)
                #     # customer_number = order[1:16]
                #      print(start, end)
                     key = line[12:]
                     # print (key)
                     key = key.rstrip('\n')
                     if (not key):
                         # print("not")
                         continue



                d[key] = (order[start:end])
        # print(list)
        list.append(d)

# print(list)
'''send orders'''

url = "https://api.icount.co.il/api/v3.php/auth/login"

d = {}
d["user"] = "ariege88"
d["cid"] = "phdpltd"
d["pass"] = "7881Aa"
jsonData = requests.post(url, d)
result = jsonData.json()

api_orders = "https://api.icount.co.il/api/create_doc.php"
# for x in range (0, list.__len__()):
#     # c = (list[x]['*customer name'])
#     data = {}
#     data["user"] = "ariege88"
#     data["compID"]="phdpltd"
#     data["pass"] = "7881Aa"
#     # data["sid"]=result['sid']
#     data["sid"]=result['sid']
#     # data["dateissued"] = list[x]['*date reference']
#     data["dateissued"] = "20180204"
#     data["validity"] = "20180301"
#     # data["clientname"] = c
#     data["docType"] = "order"
#     data["paidincvat"] = "10"
#     data["taxexempt"] = ""
#     # data["desc[]"] = list[x]['*product name']
#     # data["quantity[]"] = list[x]['*quantity 3 last digit it for after point dont put sign point ="." it need to be !=0']
#     # data["unitprice[]"] = list[x]['*price 3 last digit it for after point dont put sign point ="." ']
#     data["currency"] = "5"
#     data["debug"] = "yes"
#
#     data["show_response"] = "1"
#     # data["limit"] = "10"
#     json = requests.post(api_orders,data)
#     # info = json.json()
#     print (json.text)
# print ('done_orders')

for x in range (0, list.__len__()):
    data = {}
    quantiti = float(list[x]['*quantity 3 last digit it for after point dont put sign point ="." it need to be !=0'])/1000
    price = float(list[x]['*price 3 last digit it for after point dont put sign point ="." '])/1000
    print (price)
    data["user"] = "ariege88"
    data["compID"]="phdpltd"
    data["pass"] = "7881Aa"
    # data["sid"]=result['sid']
    data["sid"]=result['sid']
    data["dateissued"] = list[x]['*date reference']
    data["validity"] = "20180301"
    data["clientname"] = (list[x]['*customer name']).encode('cp1252').decode('cp1255',errors='replace')
    data["docType"] = "order"
    data["paidincvat"] = "10"
    data["taxexempt"] = ""
    data["desc[]"] = list[x]['*product name'].encode('cp1252').decode('cp1255',errors='replace')
    data["quantity[]"] = str(quantiti)
    data["unitprice[]"] = str(price)
    data["currency"] = "1"
    data["debug"] = "yes"
    data["totalsum"] = str(quantiti*price)
    data["show_response"] = "1"
    json = requests.post(api_orders,data)
    print (json.text)
# print ('done_orders')
